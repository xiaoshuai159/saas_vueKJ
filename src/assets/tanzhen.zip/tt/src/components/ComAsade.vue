<template>
    <el-menu 
    default-active="active" 
    class="el-menu-vertical-demo" 
    @open="handleOpen" 
    @close="handleClose" :collapse="isCollapse"
    background-color="#545c64"
    text-color="#fff"
    active-text-color="#ffd04b"
    router>
        <h3>探 针</h3>
        <el-menu-item index="/layout/control">
            <i class="el-icon-location"></i>
            <span slot="title">控制端</span>
        </el-menu-item>

        <el-menu-item index="/layout/view">
            <i class="el-icon-menu"></i>
            <span slot="title">重放</span>
        </el-menu-item>

        <el-menu-item index="/layout/other">
            <i class="el-icon-setting"></i>
            <span slot="title">其他</span>
        </el-menu-item>

</el-menu>

</template>



<style lang="less" scoped>
    .el-menu-vertical-demo:not(.el-menu--collapse) {
        width: 200px;
        min-height: 400px;
    }
    
    .el-menu {
        height: 100vh;
    }
    
    h3 {
        color: aliceblue;
        text-align: center;
        font-size: 48px;
    }
</style>

<script>
    export default {
        data() {
            return {
                isCollapse: false
            };
        },
        methods: {
            handleOpen(key, keyPath) {
                console.log(key, keyPath);
            },
            handleClose(key, keyPath) {
                console.log(key, keyPath);
            }
        }
    }
</script>