<template>
    <el-menu 
    :default-active="active" 
    mode="horizontal" 
    background-color="#545c64"
    text-color="#fff"
    active-text-color="#ffd04b"
    router
    >
        <!-- <el-menu-item index="/">首页</el-menu-item> -->
        <el-menu-item index="/control">控制中心</el-menu-item>
        <el-menu-item index="/view">数据可视化</el-menu-item>
        <el-menu-item index="/other">其他</el-menu-item>

    </el-menu>
 </template>

<script>
    export default {
        data() {
            return {
                active: "/"
            }
        }

    }
</script>

<style>

</style>