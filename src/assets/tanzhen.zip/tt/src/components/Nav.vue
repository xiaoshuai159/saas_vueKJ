<template>
    <div class="header-container">
        <div class="1-content"><el-button icon="el-icon-sunset" size="mini"></el-button>
            <span class="text">欢迎使用</span></div>
        <!-- 面包屑 -->
        
        <div class="r-content">
            <el-dropdown @command="handleCommand">
                <span class="el-dropdown-link">
                    <img class='img' src="../assets/user.png" alt="">
                        
                </span>
                    <el-dropdown-menu slot="dropdown" size="small">
                        <el-dropdown-item command="a">个人中心</el-dropdown-item>
                        <el-dropdown-item command="b">退出</el-dropdown-item>
                    </el-dropdown-menu>
            </el-dropdown>
        </div> 
    </div>

</template>

<script>

export default {
    data() {
        return {

        }
    },
    methods:{
        handleCommand(command) {
        if(command==='b'){
            //console.log('惦记了');
            this.$router.push({path:'/'})
        }
      }


    }
}
</script>


<style lang="less" scoped>
    .header-container {
        padding: 20px;
        background-color: #333;
        height: 30px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        .text {
            color: #fff;
            padding: 20px;
            font-size: 13px;
        }
        .r-content{
            .img{
                width: 40px;
                height: 40px;
                border-radius: 50%;
            }
        }
    }
</style>