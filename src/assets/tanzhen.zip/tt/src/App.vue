<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>

<script>
    export default {
        name: 'app',
        components: {}
    }
</script>

<style lang="less">
    html,
    h3,
    body {
        margin: 0;
        padding: 0;
    }
</style>