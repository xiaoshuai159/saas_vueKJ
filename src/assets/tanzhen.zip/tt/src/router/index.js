import Vue from 'vue'
import VueRouter from 'vue-router'
import layout from '../views/layout.vue'
import control from '../views/main/control.vue'
import view from '../views/main/view.vue'
import other from '../views/main/other.vue'
import login from '../views/login.vue'


Vue.use(VueRouter)

const routes = [{
        path: '/layout',
        //name: 'layout',
        component: layout,
        children: [{
                path: 'control',
                name: 'control',
                component: control,
                meta: {
                    islogin: true
                }

            },
            {
                path: 'view',
                name: 'view',
                component: view,
                meta: {
                    islogin: true
                }
            },
            {
                path: 'other',
                name: 'other',
                component: other,
                meta: {
                    islogin: true
                }
            },
        ]
    },
    {
        path: '/',
        name: 'login',
        component: login
    }

]

const router = new VueRouter({
    mode: 'history',
    base: process.env.BASE_URL,
    routes
})

export default router