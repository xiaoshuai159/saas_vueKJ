import router from "./index"

router.beforeEach((to, from, next) => {
    if (to.meta.islogin) {
        let token = false;
        if (token) {
            next();
        } else {
            next({
                name: 'login'
            })
        }
    } else {
        next();
    }
})