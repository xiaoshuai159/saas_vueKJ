<template>
   <div>
    <!-- <HeaderNav /> -->
    <el-container>
        <el-aside width="200px">
            <ComAsade />
            <!-- <HeaderNav /> -->
        </el-aside>
        <el-container>

          <el-header>
                <Nav />
          </el-header>

          <el-main><router-view></router-view></el-main>
        </el-container>
      </el-container>
   </div>
</template>

<script>
    //import headerNav from '@/components/headerNav.vue';
    import ComAsade from '@/components/ComAsade.vue';
    import Nav from '@/components/Nav.vue'
    export default {
        components: {
            //headerNav,
            //HeaderNav
            ComAsade,
            Nav
        }

    }
</script>

<style>
    .el-header {
        padding: 0;
    }
</style>